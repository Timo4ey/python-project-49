# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games.answer_loop',
 'brain_games.asker',
 'brain_games.greeting',
 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.2.22',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Timo4ey/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Timo4ey/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/06c65a8ab4af5d81aca8/maintainability)](https://codeclimate.com/github/Timo4ey/python-project-49/maintainability)\n\n## Brain-even, an example of using:\n[![asciicast](https://asciinema.org/a/OJjhfVJOgR9GSkuoUBBJiCIml.svg)](https://asciinema.org/a/OJjhfVJOgR9GSkuoUBBJiCIml)\n\n',
    'author': 'Timofey',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
