### Hexlet tests and linter status:
[![Actions Status](https://github.com/Timo4ey/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Timo4ey/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/06c65a8ab4af5d81aca8/maintainability)](https://codeclimate.com/github/Timo4ey/python-project-49/maintainability)

## Brain-even, an example of using:
[![asciicast](https://asciinema.org/a/OJjhfVJOgR9GSkuoUBBJiCIml.svg)](https://asciinema.org/a/OJjhfVJOgR9GSkuoUBBJiCIml)

