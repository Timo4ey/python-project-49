# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games.games',
 'brain_games.scripts',
 'brain_games.scripts.answer_loop',
 'brain_games.scripts.asker',
 'brain_games.scripts.create_example',
 'brain_games.scripts.greeting']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = brain_games.games.brain_games:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.5.1',
    'description': '',
    'long_description': "### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Timo4ey/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Timo4ey/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/06c65a8ab4af5d81aca8/maintainability)](https://codeclimate.com/github/Timo4ey/python-project-49/maintainability)\n\n## How to build and start the program\n1. Make a clone from this repo\n2. Use command `make build`to create download file\n<br> If you don't want to install it into your system than you can activate environment `poetry shell` and \ninstall into it\n3. Use command `make publish`\n4. Install the application through `make package-install`\n[![asciicast](https://asciinema.org/a/Qi9aLY9EfbVY4ahkuWJJq5Ndb.svg)](https://asciinema.org/a/Qi9aLY9EfbVY4ahkuWJJq5Ndb)\n\n## Brain-even, an example of using:\n[![asciicast](https://asciinema.org/a/hURrtchnt8VoZ0Q7pehxBJAsC.svg)](https://asciinema.org/a/hURrtchnt8VoZ0Q7pehxBJAsC)\n\n## Brain calc, an example of using:\n[![asciicast](https://asciinema.org/a/z28aJxLGfhWvYnFQZQLc1ghkY.svg)](https://asciinema.org/a/z28aJxLGfhWvYnFQZQLc1ghkY)\n\n## Brain gcd, an example of using:\n[![asciicast](https://asciinema.org/a/H5KVVxoD0F1YWjvgbI7F5adco.svg)](https://asciinema.org/a/H5KVVxoD0F1YWjvgbI7F5adco)\n\n## Brain progression, an example of using:\n[![asciicast](https://asciinema.org/a/5uiACtgamCET81b2UIEIvg98M.svg)](https://asciinema.org/a/5uiACtgamCET81b2UIEIvg98M)\n\n## Brain prime, an example of using:\n[![asciicast](https://asciinema.org/a/TirwomEocN5BlQdvnoCBT29o6.svg)](https://asciinema.org/a/TirwomEocN5BlQdvnoCBT29o6)\n",
    'author': 'Timofey',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
